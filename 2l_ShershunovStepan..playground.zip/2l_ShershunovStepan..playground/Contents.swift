import UIKit

print("")
print("1. Написать функцию, которая определяет, четное число или нет.")
print("")

let a = 999999999

if a % 2  == 0{
    print("Четное")
}
else if a == 0{
    print("Нуль")
}
else {
    print("Нечет")
}

print("")
print("2. Написать функцию, которая определяет, делится ли число без остатка на 3.")
print("")

if a % 3 != 0 {
    print("Число не делится на 3 без остатка")
}
else if a % 3 == 0 {
    print("Делится на 3 без остатка")
}


print("")
print("3. Создать возрастающий массив из 100 чисел.")
print("")

var Array = [Int]()
var i = 0
for i in (0...99) {
    Array.append(i + 4)}
//print(Array)

print("")
print("4. Удалить из этого массива все четные числа и все числа, которые не делятся на 3.")
print("")

var x = 0
//print(Array.count)

while (x != Array.count) {
    if Array[x] % 2 == 0 {
        Array.remove(at: x )
      
    }
    else if Array[x] % 3 == 0 {
    Array.remove(at: x)

}
    else {
        x += 1
    }
}
print(Array)
//print(Array.count)



print("")
print("5. * Написать функцию, которая добавляет в массив новое число Фибоначчи, и добавить при помощи нее 100 элементов.Числа Фибоначчи определяются соотношениями Fn=Fn-1 + Fn-2.")
print("")

var Ar = [Double]()
var d: Double  = 0
Ar.append(0)
Ar.append(1)

while (Ar.count < 100)  {
    
    d = Ar[Ar.count - 1] + Ar[Ar.count - 2]
    Ar.append(d)
}

print(Ar)
print("")
//print(Ar.count)



//6. * Заполнить массив из 100 элементов различными простыми числами. Натуральное число, большее единицы, называется простым, если оно делится только на себя и на единицу. Для нахождения всех простых чисел не больше заданного числа n, следуя методу Эратосфена, нужно выполнить следующие шаги:
//a. Выписать подряд все целые числа от двух до n (2, 3, 4, ..., n).
//b. Пусть переменная p изначально равна двум — первому простому числу.
//c. Зачеркнуть в списке числа от 2p до n, считая шагами по p (это будут числа, кратные p: 2p, 3p, 4p, ...).
//d. Найти первое не зачёркнутое число в списке, большее, чем p, и присвоить значению переменной p это число.
//e. Повторять шаги c и d, пока возможно.


//________________________________________________________________________________
//Выписать подряд все целые числа от двух до n (2, 3, 4, ..., n).

var sostChisla = [Int]()
var n = 499

var z = 2
while (sostChisla.count < n) {
sostChisla.append(z)
    z += 1
}

print(sostChisla)
print(sostChisla.endIndex)

//b. Пусть переменная p изначально равна двум — первому простому числу.

var p = 2
z = 2
//c. Зачеркнуть в списке числа от 2p до n, считая шагами по p (это будут числа, кратные p: 2p, 3p, 4p, ...).

for _ in sostChisla{
    
    while (z * p <=  sostChisla[sostChisla.count - 1]) {
        
        if (sostChisla[z] == z * p ){
            sostChisla.remove(at: z)
        }
        else{
            z += 1
        }
        }
    }
        
print(sostChisla)
print(sostChisla.endIndex)


//d. Найти первое не зачёркнутое число в списке, большее, чем p, и присвоить значению переменной p это число.
//c. Зачеркнуть в списке числа от 2p до n, считая шагами по p (это будут числа, кратные p: 2p, 3p, 4p, ...).
//e. Повторять шаги c и d, пока возможно.

var q = 0
var prostChisla = [Int] ()
p = 2
z = 1
var w = 0
for _ in sostChisla {
    
    if (p < sostChisla[q]) {
        p = sostChisla[q]
        
    }
    
    else {
        
    }
    
    while (w <= sostChisla.endIndex || (p * z) <= sostChisla[sostChisla.endIndex]) {
       
        if (sostChisla[w] % (p * z) != 0){
            prostChisla.append(sostChisla[w])
           
            break
        }
        else {
            z += 1
         
             }
        }
   
    q += 1
    w += 1
}
        
print(prostChisla)
print(prostChisla.count)


