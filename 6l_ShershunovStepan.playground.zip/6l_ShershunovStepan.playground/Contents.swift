import UIKit

//1. Реализовать свой тип коллекции «очередь» (queue) c использованием дженериков.
//2. Добавить ему несколько методов высшего порядка, полезных для этой коллекции (пример:
//filter для массивов)
//3. *Добавить свой subscript, который будет возвращать nil в случае обращения к
//несуществующему индексу.


class Car {
    var mark: String
    var windows: String
    var forsage: Bool
    
    func Forsage(){
    }
    
    init(mark: String, windows: String, forsage: Bool) {
        self.mark = mark
        self.windows = windows
        self.forsage = forsage
    }
}

class TrunkCar {
    var mark: String
    var windows: String
    var trunk: Int
    
    func Load(){
    }
    
    init(mark: String, windows: String,trunk:Int) {
        self.mark = mark
        self.windows = windows
        self.trunk = trunk
    }
}


struct Fifo<T> {
    
  private var elements: [T] = []
  mutating func add(_ element: T) {
        elements.append(element)
    }
    mutating func take() -> Int {
        if elements.count > 0 {
            print("\(elements.removeLast())")
          
            return elements.endIndex
        }
        else{
            print("Массив закончился")
          return 0
        }
    }
    
    mutating func count() {
        print(elements.count)
    }
    
}

var stackCar = Fifo<Car>()

stackCar.add(Car(mark: "Ford", windows: "open", forsage: true))
stackCar.add(Car(mark: "Mazda", windows: "close", forsage: false))

stackCar.self
stackCar.count()


print(stackCar.take())
stackCar.count()

var stCar = Fifo<TrunkCar>()

stCar.add(TrunkCar(mark: "MAZ", windows: "close", trunk: 345))
//stCar.add(Car(mark: "sdfs", windows: close, forsage: true))
stCar.add(TrunkCar(mark: "KAMAZ", windows: " open", trunk: 3212312))
stackCar.count()
stCar.count()
stCar.take()
stCar.take()
stCar.take()
stCar.take()
stCar.add(TrunkCar(mark: "KAMAZ", windows: " open", trunk: 3212312))
stCar.add(TrunkCar(mark: "KAMAZ", windows: " open", trunk: 3212312))
stCar.take()
