import UIKit

//1. Описать несколько структур – любой легковой автомобиль и любой грузовик.
//2. Структуры должны содержать марку авто, год выпуска, объем багажника/кузова, запущен ли двигатель, открыты ли окна, заполненный объем багажника.
//3. Описать перечисление с возможными действиями с автомобилем: запустить/заглушить двигатель, открыть/закрыть окна, погрузить/выгрузить из кузова/багажника груз определенного объема.
//4. Добавить в структуры метод с одним аргументом типа перечисления, который будет менять свойства структуры в зависимости от действия.
//5. Инициализировать несколько экземпляров структур. Применить к ним различные действия.
//6. Вывести значения свойств экземпляров в консоль.



enum openCloseWindows {
   
    case  Open
    case  Close
}

struct Car {
    
    let markCar: String
    let productionYear: Int
    let volumeTrunk: Int
    var engine: Bool
    var windows: String
    var filledVolume: Int
    
    mutating func Start() {
        self.engine = true
    }
    mutating func Stop() {
        self.engine = true
    }
    mutating func load (gruz:Int) {
        
        if (filledVolume + gruz > volumeTrunk) {
            print("Перегруз")
        }
       
        else if (gruz <= 0) {
            print("Нечего загружать")
        }
        else if (filledVolume + gruz <= volumeTrunk) {
            filledVolume.self += gruz
            print("Загрузили \(gruz), можно добавить " )
         }
    }
    func description () {
        print("Марка \(markCar) год выпуска \(productionYear) обьем кузова/багажника \(volumeTrunk), уже загружено \(filledVolume)  двигатель \(engine) окна \(windows)")
    }
}


struct Truck {
    
    let markCar: String
    let productionYear: Int
    let volumeTrunk: Int
    var engine: Bool
    var windows: String
    var filledVolume: Int
    
    mutating func Start() {
        self.engine = true
    }
    mutating func Stop() {
        self.engine = true
    }
    mutating func load (gruz:Int) {
        
        if (filledVolume + gruz > volumeTrunk) {
            print("Перегруз")
        }
       
        else if (gruz <= 0) {
            print("Нечего загружать")
        }
        else if (filledVolume + gruz <= volumeTrunk) {
            filledVolume.self += gruz
            print("Загрузили \(gruz), можно добавить " )
         }
    }
    func description () {
        print("Марка \(markCar) год выпуска \(productionYear) обьем кузова/багажника \(volumeTrunk), уже загружено \(filledVolume)  двигатель \(engine) окна \(windows)")
    }
    mutating func window(openClose:openCloseWindows) {
    
        switch openClose {
    case .Open:
        self.windows = "Open"
    case .Close:
        self.windows = "Close"
        
    }
    }
}


var tuc = Truck(markCar: "Ford", productionYear: 1567, volumeTrunk: 1000, engine: false, windows: "open" , filledVolume: 120)

print(tuc.engine)
tuc.Start()
print(tuc.engine)
tuc.load(gruz: 1000)
tuc.Start()

print(tuc.engine)
tuc.description()
tuc.window(openClose: .Close)
print(tuc)
