import UIKit

//1. Описать класс Car c общими свойствами автомобилей и пустым методом действия по аналогии с прошлым заданием.
//2. Описать пару его наследников trunkCar и sportСar. Подумать, какими отличительными свойствами обладают эти автомобили. Описать в каждом наследнике специфичные для него свойства.
//3. Взять из прошлого урока enum с действиями над автомобилем. Подумать, какие особенные действия имеет trunkCar, а какие – sportCar. Добавить эти действия в перечисление.
//4. В каждом подклассе переопределить метод действия с автомобилем в соответствии с его классом.
//5. Создать несколько объектов каждого класса. Применить к ним различные действия.
//6. Вывести значения свойств экземпляров в консоль.




//1. Описать класс Car c общими свойствами автомобилей и пустым методом действия по аналогии с прошлым заданием.

enum Palitra {
    case black, brown, white, blue
}

class Car {
    var color: UIColor
    let mark: String
    let prodactionYear: Int
    var maxSpeed:Int
    var engine: Bool
    
    init (color: UIColor, mark: String, prodactionYear: Int, maxSpeed: Int,  engine: Bool) {

        self.color = color
        self.mark = mark
        self.prodactionYear = prodactionYear
        self.maxSpeed = maxSpeed
        self.engine = engine
    }
    
func description (){
    print("Цвет \(engineCondition(color: color.self)) марка \(mark) год выпуска \(prodactionYear) максимальная скорость \(maxSpeed) двигатель ")
    }
    
    func recolor (colorCar: Palitra){
        switch colorCar {
        case .black:
            self.color = .black
        case .brown:
            self.color = .brown
        case .white:
            self.color = .white
        case .blue:
            self.color = .blue
        }
      }
    func engineCondition (color: UIColor) -> String {
       var a: String = "не понятно"
        if (self.color == .blue) {
            a = "Синий"
        }
        if (self.color == .brown) {
            a = "Коричневый"
        }
        if (self.color == .white ) {
            a = "Белый"
        }
        if (self.color == .black) {
            a = "Черный"
        }
        return a
    }
}


var tachka = Car(color: .cyan, mark: "Ford", prodactionYear: 1988, maxSpeed: 200, engine: false)
tachka.description()
tachka.recolor(colorCar: .blue)
tachka.description()

enum OpenClose {
    case open, close
}



class littleCar: Car {
    
    var hatch: String
    
    init (color: UIColor, mark: String, prodactionYear: Int, maxSpeed: Int,  engine: Bool, hatch: String) {
       
        self.hatch = hatch
    
        super.init (color: color, mark: mark, prodactionYear: prodactionYear, maxSpeed: maxSpeed,  engine: engine)
    
    }
    
    func hatchOpenClose (hatchOP: OpenClose) {
       
        switch hatchOP {
        case .open:
            hatch = "Открыли"
        case .close:
            hatch = "Закрыли"
        }
    }
    
    
    override func description() {
        print("Цвет \(engineCondition(color: color.self)) марка \(mark) год выпуска \(prodactionYear) максимальная скорость \(maxSpeed) двигатель люк \(hatch)")

    }
}

var littleTachka = littleCar(color: .cyan, mark: "VW", prodactionYear: 234, maxSpeed: 400, engine: .random(), hatch: "Надо посмотреть")

littleTachka.description()
littleTachka.hatch
littleTachka.hatchOpenClose(hatchOP: .open)
littleTachka.description()
tachka.description()
littleTachka.recolor(colorCar: .white)


littleTachka.description()
tachka.description()
