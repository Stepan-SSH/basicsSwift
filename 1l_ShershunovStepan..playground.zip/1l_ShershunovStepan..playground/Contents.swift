import UIKit

//Part 1


import UIKit
import PlaygroundSupport

var a: Float  = 1
var b: Float  = 2
var c: Float  = 1

var d: Float = b*b-4*a*c

if d  == 0 {
    print("Ответ Х1=Х2=\(-b/a/a)")
}
else if d < 0 {
    print("Уравнение не имеет решений")
}
else {
    print("Ответ на квадратное уравнение Х1 =\((-b+sqrt(d))/(2*a)), Х2 =\((-b-sqrt(d))/(2*a))")
}


//Part 2

var sideA: Float = 856
var sideB: Float = 876
let sideC: Float = sqrt(sideA*sideA + sideB*sideB)
let square = 0.5*sideA*sideB
let perimeter = sideA + sideB + sideC

print ("Площадь треугольника равна: \(square)")
print ("Периметр треугольника равен: \(perimeter)")
print ("Гипотенуза равна: \(sideC)")


//Part 3

let mnogoDeneg: Double = 10
let stavkaP: Double = 10
var nachisleniya: Double = stavkaP/100
var skolkoLet = 5
var i = 1

var yearVar2 = mnogoDeneg + mnogoDeneg*nachisleniya
while i<skolkoLet {
i = i + 1
    yearVar2 = yearVar2 + yearVar2*nachisleniya
    }
print ("Общая сумма через \(skolkoLet): \(yearVar2)")


var year: Double = mnogoDeneg + mnogoDeneg*nachisleniya

var year1: Double = year + year*nachisleniya

var year2: Double = year1 + year1*nachisleniya

var year3: Double = year2 + year2*nachisleniya

var year4: Double = year3 + year3*nachisleniya

print("Общая сумма составила: \(year4)")
