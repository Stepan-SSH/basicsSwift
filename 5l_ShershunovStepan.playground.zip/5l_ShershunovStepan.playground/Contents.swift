import UIKit

//    1. Создать протокол «Car» и описать свойства, общие для автомобилей, а также метод действия.
//    2. Создать расширения для протокола «Car» и реализовать в них методы конкретных действий с автомобилем: открыть/закрыть окно, запустить/заглушить двигатель и т.д. (по одному методу на действие, реализовывать следует только те действия, реализация которых общая для всех автомобилей).
//    3. Создать два класса, имплементирующих протокол «Car» - trunkCar и sportСar. Описать в них свойства, отличающиеся для спортивного автомобиля и цистерны.
//    4. Для каждого класса написать расширение, имплементирующее протокол CustomStringConvertible.
//    5. Создать несколько объектов каждого класса. Применить к ним различные действия.
//    6. Вывести сами объекты в консоль.

protocol protocolCar {
    
    var window: Bool { get set }
    var engine: Bool { get set }
    var mark: String { get }
    var yearProduction: Int { get }
    var color: UIColor { get set }
    
    func startStop()
    
}

class Car: protocolCar {

    var window: Bool
    var engine: Bool
    var mark: String
    var yearProduction: Int
    var color: UIColor

    
    init (window: Bool, engine: Bool, mark: String, yearProduction: Int, color: UIColor) {
        
        self.window = window
        self.engine = engine
        self.mark = mark
        self.yearProduction = yearProduction
        self.color = color
       
    }
        func windows() {
        print(window)
    }
    
    func startStop() {
        print(engine)
    }
}


class trunkCar: protocolCar {
    
    var window: Bool
    var engine: Bool
    var mark: String
    var yearProduction: Int
    var color: UIColor
    var trunk: Int
    
    init (window: Bool, engine: Bool, mark: String, yearProduction: Int, color: UIColor, trunk: Int) {
        
        self.window = window
        self.engine = engine
        self.mark = mark
        self.yearProduction = yearProduction
        self.color = color
        self.trunk = trunk
    }
        func windows() {
        print(window)
    }
    func startStop() {
        print(engine)
    }
    func load(skoka: Int) {
        if trunk.self < 1000 {
            trunk.self += skoka
            if trunk.self >= 1000 {
                print("Перегруз")
                trunk.self = trunk.self - skoka
            }
            else{
            print("Загрузили, теперь загружено \(trunk.self)")
            }
        }
    }
    
    func unload(skoka: Int) {
        if trunk.self - skoka > 0 {
            trunk.self -= skoka
            print("Разгрузили, теперь загружено \(trunk.self)")
            }
        else {
            print("Надо ввести другое значение")
        }
}
}





var a = Car(window: false, engine: false, mark: "Ford", yearProduction: 1986, color: .blue)

print(a)
a.windows()
print(a)
a.windows()
//a.recolor(color: .brown)

enum Palitra {
case black, brown, white, blue
}


extension protocolCar {

    mutating func recolor(color: Palitra) {
        
        switch color {
        case .brown:
            
            if self.color == .brown {
                print("Цвет как и был, так и остался коричневым")
            }
            else{
                self.color = .brown
                print("Перекрасили в коричневый")}
            
        case .blue:
            if self.color == .blue {
                print("Цвет как и был, так и остался синим")
            }
            else {
            self.color = .blue
            print("Перекрасили в синий")}
       
        case .black:
            if self.color == .black {
                print("Цвет как и был, так и остался черным")
            }
            else {
            self.color = .black
                print("Перекрасили в черный")}
            
        case .white:
            if self.color == .white {
                print("Цвет как и был, так и остался белым")
            }
            else {
            self.color = .white
            print("Перекрасили в белый")
            }
        }
    }
}

var b = trunkCar(window: false, engine: true, mark: "MAZ", yearProduction: 5432, color: .blue, trunk: 100)

print(b)
b.color
b.recolor(color: .brown)
b.color
print(b)
b.recolor(color: .brown)
b.recolor(color: .white)
b.recolor(color: .white)


a.recolor(color: .brown)

b.trunk
b.unload(skoka: 500)
