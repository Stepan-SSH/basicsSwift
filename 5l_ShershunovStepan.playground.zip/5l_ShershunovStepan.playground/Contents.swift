import UIKit

//    1. Создать протокол «Car» и описать свойства, общие для автомобилей, а также метод действия.
//    2. Создать расширения для протокола «Car» и реализовать в них методы конкретных действий с автомобилем: открыть/закрыть окно, запустить/заглушить двигатель и т.д. (по одному методу на действие, реализовывать следует только те действия, реализация которых общая для всех автомобилей).
//    3. Создать два класса, имплементирующих протокол «Car» - trunkCar и sportСar. Описать в них свойства, отличающиеся для спортивного автомобиля и цистерны.
//    4. Для каждого класса написать расширение, имплементирующее протокол CustomStringConvertible.
//    5. Создать несколько объектов каждого класса. Применить к ним различные действия.
//    6. Вывести сами объекты в консоль.

protocol protocolCar {
    
    var window: Bool { get set }
    var engine: Bool { get set }
    var mark: String { get }
    var yearProduction: Int { get }
    var color: UIColor { get set }
    
    func windows()
    func startStop()
    func recolor()
    
}



class Car: protocolCar {

    var window: Bool
    var engine: Bool
    var mark: String
    var yearProduction: Int
    var color: UIColor
    
    init (window: Bool, engine: Bool, mark: String, yearProduction: Int, color: UIColor) {
        
        self.window = window
        self.engine = engine
        self.mark = mark
        self.yearProduction = yearProduction
        self.color = color
    }
    
        
    func windows() {
        print(window)
    }
    
    func startStop() {
        print(engine)
    }
    
    func recolor() {
        print(color.description     )
    }
}




var a = Car(window: false, engine: false, mark: "Ford", yearProduction: 1986, color: .blue)
a.recolor()
print(a)
a.windows()
print(a)
